Note: 
- `bin/` contains some bash scripts used by the plugin. Add it to your `PATH`.
- Some code in `ftplugin/tex/live-latex-preview.vim` are commented. That part is not necessary for `pathogen` or `Vundle` users.

Warning:
- This is an unofficial clone of vim-live-latex-preview by Kevin C. Klement <klement@philos.umass.edu>
- For licence info and more details please visit https://aur.archlinux.org/packages/vim-live-latex-preview.

More on editing LaTeX under Vim:
- https://github.com/LaTeX-Box-Team/LaTeX-Box
- http://jlebl.wordpress.com/2011/01/13/vim-evince-and-forward-and-backward-latex-synctex-search/
